//
//  UIImage+Resize.swift
//  MyLocations
//
//  Created by Bane Manojlovic on 27/07/2020.
//  Copyright © 2020 Bane Manojlovic. All rights reserved.
//

import Foundation
import UIKit

extension UIImage {
    
    // Method for resizing image in Locations list
    func resized(withBounds bounds: CGSize) -> UIImage {
        let horizontalRatio = bounds.width / size.width
        let verticalRatio = bounds.height / size.height
        let ratio = min(horizontalRatio, verticalRatio)
        let newSize = CGSize(width: size.width * ratio, height: size.height * ratio)
        
        UIGraphicsBeginImageContextWithOptions(newSize, true, 0)
        
        draw(in: CGRect(origin: CGPoint.zero, size: newSize))
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
}
