//
//  MyTabBarController.swift
//  MyLocations
//
//  Created by Bane Manojlovic on 27/07/2020.
//  Copyright © 2020 Bane Manojlovic. All rights reserved.
//

import Foundation
import UIKit

class MyTabBarController: UITabBarController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override var childForStatusBarStyle: UIViewController? {
        return nil
    }
}
